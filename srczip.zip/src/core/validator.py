from .data_models import ChartData, ValidationResult
from .config import ChartConfig
from typing import Dict, Any
import logging

logger = logging.getLogger(__name__)

class DataValidator:
    """Streamlined data validation with accuracy focus"""
    
    def __init__(self, config: ChartConfig):
        self.config = config
    
    def validate_chart_data(self, data: ChartData) -> ValidationResult:
        """Validate chart data for accuracy and completeness"""
        issues = []
        
        # Check minimum data requirements
        if len(data.values) < self.config.MIN_DATA_POINTS:
            issues.append(f"Insufficient data points: {len(data.values)} < {self.config.MIN_DATA_POINTS}")
        
        # Check source traceability
        unique_sources = len(set(data.source_ids))
        if unique_sources < self.config.MIN_SOURCES:
            issues.append(f"Insufficient source diversity: {unique_sources} < {self.config.MIN_SOURCES}")
        
        # Check confidence levels
        avg_confidence = data.get_average_confidence()
        low_confidence_count = sum(1 for c in data.confidence_scores if c < self.config.MIN_CONFIDENCE)
        
        if avg_confidence < self.config.MIN_CONFIDENCE:
            issues.append(f"Low average confidence: {avg_confidence:.3f}")
        
        if low_confidence_count > len(data.confidence_scores) * 0.3:
            issues.append(f"Too many low-confidence data points: {low_confidence_count}")
        
        # Determine validation result
        is_valid = len(issues) == 0 and avg_confidence >= self.config.MIN_CONFIDENCE
        requires_review = avg_confidence < 0.8 or len(issues) > 0
        
        result = ValidationResult(
            is_valid=is_valid,
            confidence=avg_confidence,
            issues=issues,
            requires_human_review=requires_review,
            source_count=unique_sources
        )
        
        # Log validation for audit trail
        logger.info(f"Validated chart {data.chart_id}: valid={is_valid}, confidence={avg_confidence:.3f}")
        
        return result
    
    def export_validation_report(self, data: ChartData, result: ValidationResult) -> Dict[str, Any]:
        """Generate validation report for audit trail"""
        return {
            'chart_id': str(data.chart_id),
            'validation_timestamp': data.timestamp.isoformat(),
            'is_valid': result.is_valid,
            'confidence': result.confidence,
            'issues': result.issues,
            'requires_review': result.requires_human_review,
            'data_summary': {
                'total_points': len(data.values),
                'unique_sources': result.source_count,
                'chart_type': data.chart_type.value
            }
        }