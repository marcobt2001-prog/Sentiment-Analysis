from pydantic import BaseModel, Field, validator
from typing import List, Dict, Any, Optional
from datetime import datetime
from uuid import uuid4, UUID
from enum import Enum

class ChartType(str, Enum):
    EMERGENT_THEMES = "emergent_themes"
    GROUP_SENTIMENT = "group_sentiment" 
    RISK_MATRIX = "risk_matrix"
    CULTURE_ANALYSIS = "culture_analysis"

class ChartData(BaseModel):
    """Core chart data with validation and traceability"""
    chart_id: UUID = Field(default_factory=uuid4)
    chart_type: ChartType
    title: str = Field(..., min_length=1)
    values: List[float] = Field(..., min_items=3)
    labels: List[str] = Field(..., min_items=3)
    source_ids: List[str] = Field(..., min_items=1)  # For traceability
    confidence_scores: List[float] = Field(..., min_items=1)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.now)
    
    @validator('confidence_scores')
    def validate_confidence(cls, v):
        if not all(0.0 <= score <= 1.0 for score in v):
            raise ValueError("Confidence scores must be between 0.0 and 1.0")
        return v
    
    @validator('values', 'labels', 'source_ids', 'confidence_scores')
    def validate_length_consistency(cls, v, values):
        if 'values' in values and len(v) != len(values['values']):
            raise ValueError("All data arrays must have the same length")
        return v
    
    def get_average_confidence(self) -> float:
        return sum(self.confidence_scores) / len(self.confidence_scores)
    
    def to_export_dict(self) -> Dict[str, Any]:
        """Export for CSV/JSON with source traceability"""
        return {
            'chart_id': str(self.chart_id),
            'chart_type': self.chart_type.value,
            'title': self.title,
            'data': list(zip(self.labels, self.values, self.source_ids, self.confidence_scores)),
            'avg_confidence': self.get_average_confidence(),
            'timestamp': self.timestamp.isoformat()
        }

class ValidationResult(BaseModel):
    """Simple validation result with clear decisions"""
    is_valid: bool
    confidence: float
    issues: List[str] = Field(default_factory=list)
    requires_human_review: bool = False
    source_count: int = 0