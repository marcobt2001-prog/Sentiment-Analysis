from dataclasses import dataclass
from typing import Dict, List

@dataclass
class ChartConfig:
    """Professional chart configuration for PowerPoint presentations"""
    # Professional styling
    DPI: int = 300
    FIGSIZE: tuple = (12, 8)
    FONT_FAMILY: str = "Arial"
    FONT_SIZE: int = 12
    
    # Professional colors (consulting standard)
    COLORS: Dict[str, str] = None
    
    # Validation thresholds
    MIN_CONFIDENCE: float = 0.7
    MIN_DATA_POINTS: int = 3
    MIN_SOURCES: int = 2
    
    def __post_init__(self):
        if self.COLORS is None:
            self.COLORS = {
                'primary': '#1f4788',
                'success': '#70ad47', 
                'warning': '#ffc000',
                'danger': '#e74c3c',
                'neutral': '#95a5a6',
                'text': '#2c3e50'
            }
    
    def get_color_palette(self, n_colors: int) -> List[str]:
        """Generate professional color palette for charts"""
        base_colors = [
            self.COLORS['primary'], self.COLORS['success'], 
            self.COLORS['warning'], self.COLORS['danger'], 
            self.COLORS['neutral']
        ]
        extended_colors = ['#3498db', '#9b59b6', '#e67e22', '#1abc9c', '#f39c12']
        all_colors = base_colors + extended_colors
        return [all_colors[i % len(all_colors)] for i in range(n_colors)]