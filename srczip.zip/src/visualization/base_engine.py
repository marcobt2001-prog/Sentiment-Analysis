import matplotlib.pyplot as plt
import pandas as pd
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional
import json

from ..core.data_models import ChartData, ValidationResult
from ..core.validator import DataValidator
from ..core.config import ChartConfig

class BaseChartEngine(ABC):
    """Streamlined base engine for professional chart generation"""
    
    def __init__(self, config: Optional[ChartConfig] = None):
        self.config = config or ChartConfig()
        self.validator = DataValidator(self.config)
        self._setup_matplotlib_style()
    
    def _setup_matplotlib_style(self):
        """Configure matplotlib for professional output"""
        plt.rcParams.update({
            'figure.dpi': self.config.DPI,
            'savefig.dpi': self.config.DPI,
            'figure.figsize': self.config.FIGSIZE,
            'font.family': self.config.FONT_FAMILY,
            'font.size': self.config.FONT_SIZE,
            'axes.spines.top': False,
            'axes.spines.right': False,
            'axes.grid': True,
            'axes.grid.alpha': 0.3,
            'figure.facecolor': 'white',
            'savefig.bbox': 'tight',
            'savefig.facecolor': 'white'
        })
    
    @abstractmethod
    def generate_chart(self, data: ChartData) -> str:
        """Generate chart and return file path"""
        pass
    
    def validate_and_generate(self, data: ChartData, output_dir: str = "charts") -> Dict[str, Any]:
        """Validate data and generate chart with full audit trail"""
        
        # Validate data first
        validation = self.validator.validate_chart_data(data)
        
        result = {
            'chart_id': str(data.chart_id),
            'validation': validation.dict(),
            'chart_path': None,
            'csv_path': None,
            'metadata': data.metadata
        }
        
        if not validation.is_valid:
            result['error'] = f"Validation failed: {', '.join(validation.issues)}"
            return result
        
        if validation.requires_human_review:
            result['warning'] = "Chart generated but requires human review"
        
        try:
            # Generate chart
            chart_path = self.generate_chart(data)
            result['chart_path'] = chart_path
            
            # Export data for transparency
            csv_path = self._export_data_csv(data, output_dir)
            result['csv_path'] = csv_path
            
        except Exception as e:
            result['error'] = f"Chart generation failed: {str(e)}"
        
        return result
    
    def _export_data_csv(self, data: ChartData, output_dir: str) -> str:
        """Export chart data as CSV for transparency"""
        Path(output_dir).mkdir(exist_ok=True)
        
        # Create DataFrame with all data
        df = pd.DataFrame({
            'label': data.labels,
            'value': data.values,
            'source_id': data.source_ids,
            'confidence': data.confidence_scores
        })
        
        csv_path = f"{output_dir}/{data.chart_type.value}_{str(data.chart_id)[:8]}.csv"
        df.to_csv(csv_path, index=False)
        
        return csv_path