"""
Streamlined Enterprise Chart Generation Tool

A focused Python package for generating professional consulting charts
with data accuracy validation and source traceability.
"""

from .core.data_models import ChartData, ChartType, ValidationResult
from .core.config import ChartConfig
from .core.validator import DataValidator
from .visualization.base_engine import BaseChartEngine

__version__ = "1.0.0"
__all__ = [
    "ChartData",
    "ChartType", 
    "ValidationResult",
    "ChartConfig",
    "DataValidator",
    "BaseChartEngine"
]